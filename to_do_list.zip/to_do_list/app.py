from flask import Flask, render_template, request, redirect, url_for


app = Flask(__name__)


tasks = [
{"id": 1, "title": "Acheter du pain", "done": False, "priority": "normale"},
{"id": 2, "title": "Réviser Flask", "done": True, "priority": "haute"},
]
_next_id = 3


@app.route("/")
def index():
    return render_template("index.html", tasks=tasks)


@app.route("/add", methods=["POST"])
def add():
   
    global _next_id
    title = request.form.get("title", "").strip()
    priority = request.form.get("priority", "normale")
    if title:
        task = {"id": _next_id, "title": title, "done": False, "priority": priority}
        tasks.append(task)
        _next_id += 1
    return redirect(url_for("index"))


@app.route("/done/<int:task_id>")
def done(task_id):
    for t in tasks:
        if t["id"] == task_id:
            t["done"] = True
            break
    return redirect(url_for("index"))


@app.route("/delete/<int:task_id>")
def delete(task_id):
    global tasks
    tasks = [t for t in tasks if t["id"] != task_id]
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)