document.addEventListener('DOMContentLoaded', function () {
const addForm = document.getElementById('addForm');
const titleInput = document.getElementById('title');
const errorSpan = document.getElementById('error');


addForm.addEventListener('submit', function (e) {
if (!titleInput.value.trim()) {
e.preventDefault();
errorSpan.textContent = 'Le titre ne peut pas être vide.';

}
});


document.querySelectorAll('.delete-btn').forEach(function (btn) {
btn.addEventListener('click', function (e) {
const ok = confirm('Voulez vous vraiment supprimer cette tache ?');
if (!ok) e.preventDefault();
});
});


const searchInput = document.getElementById('searchInput');
if (searchInput) {
searchInput.addEventListener('input', function () {
const q = this.value.toLowerCase();
document.querySelectorAll('#taskList .task').forEach(function (li) {
const title = li.querySelector('.title').textContent.toLowerCase();
li.style.display = title.includes(q) ? '' : 'none';
});
});
}
});